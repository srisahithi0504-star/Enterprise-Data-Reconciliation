# Enterprise Data Reconciliation — Starter Package

This is a guided starter scaffold for the Internship Studio Data Analytics assessment. It is not a completed solution; complete the TODOs yourself and ensure you can explain your choices.

## Folder setup
Put these source files next to `enterprise_reconciliation.ipynb`:
- `enterprise_database.db`
- `server_logs.txt`
- `daily_exchange_rates.csv`

## Open in VS Code
1. Extract this ZIP.
2. Put the three source files into the extracted project folder.
3. Open the folder in VS Code.
4. Open `enterprise_reconciliation.ipynb`.
5. Select the Python 3.14 kernel.
6. Run cells sequentially as you investigate and complete each TODO.

## Install dependencies
In VS Code terminal:
```powershell
python -m pip install ipykernel pandas matplotlib
```

## GitHub
Repository username supplied: `srisahithi0504`.
This ZIP is not uploaded to GitHub. You can create a repository on GitHub and upload the project folder yourself. Avoid uploading confidential or proprietary source datasets unless your internship instructions explicitly permit it.

## Submission reminder
The assessment brief asks for one completed `.ipynb` submission. Restart the kernel and Run All before submitting. The source data files are not included in this ZIP.
